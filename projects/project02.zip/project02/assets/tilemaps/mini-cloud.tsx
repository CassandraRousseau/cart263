<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="mini-cloud" tilewidth="60" tileheight="60" tilecount="36" columns="5">
 <grid orientation="orthogonal" width="64" height="64"/>
 <image source="../images/mini-cloud.png" width="300" height="300"/>
</tileset>
