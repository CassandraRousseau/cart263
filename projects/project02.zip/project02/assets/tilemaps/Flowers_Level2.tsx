<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Flowers_Level2" tilewidth="64" tileheight="64" tilecount="1" columns="1">
 <image source="../images/Flowers.png" width="110" height="110"/>
</tileset>
