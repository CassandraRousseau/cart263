<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="avatar" tilewidth="60" tileheight="64" tilecount="56" columns="7">
 <grid orientation="orthogonal" width="64" height="64"/>
 <image source="../images/avatar.png" width="420" height="512"/>
</tileset>
