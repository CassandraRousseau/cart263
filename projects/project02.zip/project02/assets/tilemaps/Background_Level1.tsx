<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Level1" tilewidth="800" tileheight="600" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="800" height="600" source="Background_Level1.png"/>
 </tile>
</tileset>
