<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Mini-cloud3" tilewidth="64" tileheight="64" tilecount="16" columns="4">
 <image source="../images/Mini-cloud3.png" width="300" height="300"/>
</tileset>
