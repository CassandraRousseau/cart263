<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Ground_level2" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../images/Ground_level2.png" width="128" height="64"/>
</tileset>
