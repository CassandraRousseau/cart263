<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Ground" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../images/Ground.png" width="128" height="64"/>
</tileset>
