<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="enemy" tilewidth="60" tileheight="60" tilecount="49" columns="7">
 <grid orientation="orthogonal" width="64" height="64"/>
 <image source="../images/enemy.png" width="420" height="420"/>
</tileset>
