<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Platforms_Level3" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../images/GroundLevel3.png" width="128" height="64"/>
</tileset>
