# Images folder

This is the folder where you would keep all the images associated with your project, such as `.png`, `.jpg`, and other formats. An example image, `clown.png`, is here in case you need something to play around with.
