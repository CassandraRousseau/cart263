class State {
  //Setting all the variables for each state
  constructor() {}

  //Setting preload method for each state
  preload() {}

  //Setting draw method for each state
  draw() {
    noStroke();
    fill(255);
    textFont(font);
  }

  //Setting mousePressed method for each state
  mousePressed() {}
}
